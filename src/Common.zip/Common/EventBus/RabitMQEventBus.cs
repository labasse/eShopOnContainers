﻿using Newtonsoft.Json;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Text;
using System.Threading.Tasks;

namespace eShopOnContainers.Common.EventBus
{
    public class RabbitMQEventBus : IEventBus
    {
        private const string ExchangeName = "eShopOnContainers";
        private IConnection _connection;
        private IModel _subscribeChannel;
        private string _queueName;

        public RabbitMQEventBus(string connectionString, string queueName)
        {
            ConnectionFactory factory = new ConnectionFactory();
            factory.Uri = new Uri(connectionString);

            _queueName = queueName;
            _connection = factory.CreateConnection();
            _subscribeChannel = _connection.CreateModel();
            _subscribeChannel.QueueDeclare(_queueName, false, false, false, null);
        }

        public void Dispose()
        {
            _connection.Dispose();
        }

        public void Publish<T>(T message) where T : IMessage
        {
            using(var channel = _connection.CreateModel())
            {
                var json = JsonConvert.SerializeObject(message);

                channel.QueueDeclare(_queueName, false, false, false, null);
                channel.BasicPublish(
                    exchange: "",
                    routingKey: _queueName,
                    basicProperties: null,
                    body: Encoding.UTF8.GetBytes(json)
                );
            }
        }

        public void Subscribe<T>(ISubscriber<T> subscriber) where T : IMessage
        {
            var consumer = new AsyncEventingBasicConsumer(_subscribeChannel);

            consumer.Received += (sender, args) => subscriber.OnReceived(
                JsonConvert.DeserializeObject<T>(Encoding.UTF8.GetString(args.Body.ToArray()))
            );
            _subscribeChannel.BasicConsume(_queueName, true, consumer);            
        }
    }
}
