﻿namespace eShopOnContainers.Common.EventBus
{
    public interface IMessage
    {

    }
}
